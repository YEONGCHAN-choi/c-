#pragma once
#pragma once
#include "point.h"

class block {
private:
	point cBlock[4];
	int type;
public:
	block(int t = 0) {
		cBlock[0] = point(0, 0);
		type = t;
		switch (t) {
		case 0:
			cBlock[1] = point(1, 0);
			cBlock[2] = point(2, 0);
			cBlock[3] = point(-1, 0);
			break;
		case 1:
			cBlock[1] = point(1, 0);
			cBlock[2] = point(-1, 0);
			cBlock[3] = point(-1, -1);
			break;
		case 2:
			cBlock[1] = point(-1, 0);
			cBlock[2] = point(1, 0);
			cBlock[3] = point(1, -1);
			break;
		case 3:
			cBlock[1] = point(1, 0);
			cBlock[2] = point(-1, 0);
			cBlock[3] = point(0, -1);
			break;
		case 4:
			cBlock[1] = point(1, 1);
			cBlock[2] = point(0, 1);
			cBlock[3] = point(-1, 0);
			break;
		case 5:
			cBlock[1] = point(-1, 1);
			cBlock[2] = point(0, 1);
			cBlock[3] = point(1, 0);
			break;
		case 6:
			cBlock[1] = point(1, 0);
			cBlock[2] = point(0, 1);
			cBlock[3] = point(1, 1);
			break;
		}
	}

	void Rotation(int i = 0) {
		if (type == 6) return;
		switch (i) {
		case 0:
			for (int i = 1; i <= 3; i++) {
				cBlock[i] = point(-cBlock[i].y, cBlock[i].x);
			}
			break;
		case 1:
			for (int i = 1; i <= 3; i++) {
				cBlock[i] = point(cBlock[i].y, -cBlock[i].x);
			}
		}
	}

	point & operator[](int i) {
		return cBlock[i];
	}
};