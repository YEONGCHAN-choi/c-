#pragma once
#pragma once
class point
{
public:
	int x;
	int y;

	point(int x1 = 0, int y1 = 0)
	{
		x = x1; y = y1;
	}

	point operator+(const point & p1) {
		return point(p1.x + x, p1.y + y);
	}

	point operator-(const point & p1) {
		return point(x - p1.x, y - p1.y);
	}

	point operator-() {
		return (-x, -y);
	}
};

